/*
Author       : Dreamguys
Template Name: Booking - Bootstrap Template
Version      : 1.3
*/

// (function($) {
    // "use strict";
	
	// $(document).ready(function(){
	  // $(window).scroll(function(){
		// var scroll = $(window).scrollTop();
		  // if (scroll > 150) {
			// $(".header-top").css("background" , "#2D3952");
		  // }

		  // else{
			  // $(".header-top").css("background" , "transparent");  	
		  // }
	  // })
	// })
	
// })(jQuery);